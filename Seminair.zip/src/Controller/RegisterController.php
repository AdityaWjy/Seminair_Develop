<?php
require_once('./AuthController.php');

$auth = new AuthController();
$auth->register();
